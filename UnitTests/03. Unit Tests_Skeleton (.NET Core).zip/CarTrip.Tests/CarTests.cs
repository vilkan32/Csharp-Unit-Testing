using CarTrip;
using NUnit.Framework;
using System;

namespace CarTrip.Tests
{
    
    public class Tests
    {
        
    }
}