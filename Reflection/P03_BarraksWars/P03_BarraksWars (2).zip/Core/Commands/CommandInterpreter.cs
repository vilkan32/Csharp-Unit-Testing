﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace _03BarracksFactory.Core.Commands
{
    using Contracts;
    public class CommandInterpreter : ICommandInterpreter
    {
        
        private IRepository repository;
        private IUnitFactory unitFactory;

        public CommandInterpreter(IRepository repository, IUnitFactory unitFactory)
        {
            this.repository = repository;
            this.unitFactory = unitFactory;
        }
        public IExecutable InterpretCommand(string[] data, string commandName)
        {
            var firstChar = commandName[0];
            var result = string.Empty;
            result += firstChar.ToString().ToUpper();
            for (int i = 1; i < commandName.Length; i++)
            {
                result += commandName[i].ToString().ToLower();
            }
            Type type = Type.GetType($"_03BarracksFactory.Core.Commands.{result}");
            var instance = (IExecutable)Activator.CreateInstance(type, new object[] { data, this.repository, this.unitFactory });
            return instance;

        }
    }
}
